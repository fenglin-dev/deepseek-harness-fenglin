/** Locate the DSH host package in CLI and packaged Desktop runtimes. */
/**
 * Walk up from the CLI entry first, then inspect Electron's authoritative
 * resources directory. Desktop distributions may keep node_modules outside
 * the ASAR, expose them through ASAR's virtual filesystem, or disable ASAR.
 */
export declare function findDshInstallDir(entry?: string): string | null;
