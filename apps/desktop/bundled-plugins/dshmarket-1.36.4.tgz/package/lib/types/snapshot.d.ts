/**
 * Profile snapshots — issue #98 (phase 3), implementing the snapshot half of
 * #19: before any ordering / preset change is applied, the profile's
 * composition-critical files are captured as a timestamped snapshot; a failed
 * or unwanted change can be rolled back in one step.
 *
 * A snapshot is a single JSON document under `<profile>/.dsh-market/
 * snapshots/<timestamp>-<seq>.json` holding the exact bytes of the files that
 * define the profile's composition: package.json (dependency + bundle list),
 * cordis.patch.yml (the user patch layer) and state.json (market disable
 * list + groups). Restoring validates every path (no traversal, no absolute
 * paths — same discipline as backup.ts) and writes all files from memory, so
 * a mid-restore failure cannot leave a half-written profile.
 *
 * Retention: after every create, snapshots are pruned to the most recent
 * `maxSnapshots` (default 20); the cap is configurable through the market
 * plugin config (`maxSnapshots`) and each snapshot can also be deleted
 * individually from the UI.
 */
interface SnapshotFile {
    path: string;
    /** JSON documents keep their parsed form (re-serialized on restore). */
    json?: unknown;
    /** Line-oriented text files (cordis.patch.yml) keep their lines. */
    lines?: string[];
}
export interface ProfileSnapshot {
    /** Snapshot id: the file basename without the .json suffix. */
    id: string;
    createdAt: number;
    files: SnapshotFile[];
}
/** Default number of snapshots retained; configurable via `maxSnapshots`. */
export declare const DEFAULT_MAX_SNAPSHOTS = 20;
/**
 * Prune the snapshot directory to the `max` most recent snapshots (newest
 * first). Extra ones are deleted oldest-first. A non-positive cap is clamped
 * to 1 — a 0/negative max must never drop the snapshot that was just created
 * nor invert to keeping the OLDEST set (issue #98 review hardening).
 * @returns the ids that were deleted.
 */
export declare function pruneSnapshots(profileDir: string, max: number): string[];
/**
 * Capture the profile's composition files into a new snapshot. Never throws
 * for missing optional files (cordis.patch.yml / state.json may not exist);
 * a missing package.json is not a snapshot-able profile. After creating, the
 * directory is pruned to the most recent `maxSnapshots`.
 */
export declare function createProfileSnapshot(profileDir: string, maxSnapshots?: number): ProfileSnapshot | null;
/**
 * All snapshots for a profile, newest first. Files that are unparseable,
 * shape-invalid (bad id/createdAt/files), or whose internal id does not match
 * the file name are skipped — a snapshot that could never be restored is not
 * listed (issue #98 analysis: snapshot JSON validation).
 */
export declare function listSnapshots(profileDir: string): ProfileSnapshot[];
/**
 * Restore a snapshot's files into the profile. Every file path must be one of
 * the known composition files (traversal / absolute paths are refused before
 * anything is written); each file is written via a same-directory temp +
 * rename (atomic per file), and a failure mid-restore rolls the already-
 * written files back to their pre-restore contents, so the profile is never
 * left half-restored.
 * @returns the paths restored; an error result when the snapshot is unsafe,
 * unknown, or a write failed (with any partial writes rolled back).
 */
export declare function restoreSnapshot(profileDir: string, id: string): {
    ok: boolean;
    restored: string[];
    error?: string;
};
/** Delete one snapshot; true only when it existed and was removed. */
export declare function deleteSnapshot(profileDir: string, id: string): boolean;
export {};
