'use strict'

/**
 * dsh-plugin-skills-management — Host half
 *
 * Two skill universes, one API:
 * - Market: ntd-style bundled collections (git checkouts of GitHub skill
 *   repos). Read-only, install copies into the user library.
 * - Executors: every coding agent's on-machine skills directory
 *   (`~/.claude/skills`, `~/.agents/skills`, …), following the ntd source
 *   table. Scanned for display/detail; deletable per source unless marked
 *   read-only (`agents`); any executor skill can be copied into the dsh
 *   user library so the `skill` tool can call it.
 */

const { createReadStream } = require('node:fs')
const { execFile } = require('node:child_process')
const { createShareRunJob } = require('@weibaohui/dsh-plugin-kit')
const { randomUUID } = require('node:crypto')
const fsP = require('node:fs/promises')
const { basename, join, relative, resolve, sep } = require('node:path')
const { homedir } = require('node:os')
const YAML = require('yaml')
// settings 服务要求 schemastery schema（可调用 + toJSON；zod 不兼容，register 会抛错被吞）。
// 宿主沙箱内解析打包依赖可能抛 ERR_INTERNAL_ASSERTION（.pnpm 软链），因此优先沿
// dsh 全局安装取 settings 服务自用的那份副本，本地开发/测试再退回标准 require。
function loadSchemastery() {
  const errors = []
  const { createRequire } = require('node:module')
  for (const prefix of [process.env.DSH_GLOBAL_PREFIX, join(homedir(), '.local')].filter(Boolean)) {
    const hostCopy = join(prefix, 'lib', 'node_modules', '@deepseek-ai', 'dsh', 'node_modules', '@deepseek-ai', 'schemastery', 'lib', 'index.cjs')
    try { return createRequire(hostCopy)(hostCopy) } catch (e) { errors.push(String(e && e.code || e)) }
  }
  try { return require('@deepseek-ai/schemastery') } catch (e) { errors.push(String(e && e.code || e)) }
  if (process.env.SKILLS_SETTINGS_DEBUG) console.warn(`[skills-management] schemastery unavailable: ${errors.join(' | ')}`)
  return null
}
const Schema = loadSchemastery()

const MARKET_SCAN_SKIP = new Set(['.git', 'node_modules'])
const RANK_INSTALLED = 100
const RANK_MARKET = 500
const MAX_BODY_BYTES = 64 * 1024
const DESCRIPTION_LIMIT = 140
// 同款正则见 skill/skill/src/index.ts SKILL_NAME —— 不合规的候选会让 registry 抛错
const KEBAB_NAME_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

/**
 * Known on-machine skill sources (executor → skills dir), ported from ntd's
 * `ALL_SKILL_SOURCES` table plus this machine's ZCode CLI. `sub` is relative
 * to $HOME; `dsh` is special — its root is the plugin's installedDir.
 */
const EXECUTOR_DEFS = [
  { key: 'dsh', label: 'DSH' },
  { key: 'claudecode', label: 'Claude Code', sub: '.claude/skills' },
  { key: 'zcode', label: 'ZCode', sub: '.zcode/skills' },
  { key: 'codex', label: 'Codex', sub: '.codex/skills' },
  { key: 'opencode', label: 'OpenCode', sub: '.opencode/skills' },
  { key: 'codebuddy', label: 'CodeBuddy', sub: '.codebuddy/skills' },
  { key: 'atomcode', label: 'AtomCode', sub: '.atomcode/skills' },
  { key: 'hermes', label: 'Hermes', sub: '.hermes/skills' },
  { key: 'kimi', label: 'Kimi', sub: '.kimi/skills' },
  { key: 'mobilecoder', label: 'MobileCoder', sub: '.mobile-coder/skills' },
  { key: 'codewhale', label: 'Codewhale', sub: '.codewhale/skills' },
  { key: 'kilo', label: 'Kilo', sub: '.kilo/skills' },
  { key: 'pi', label: 'Pi', sub: '.pi/skills' },
  { key: 'mimo', label: 'Mimo', sub: '.local/share/mimocode/skills' },
  { key: 'zhanlu', label: 'ZhanLu', sub: '.local/share/zhanlu/skills' },
  { key: 'workbuddy', label: 'WorkBuddy', sub: '.workbuddy/skills' },
  // agents 共享池曾是只读来源；治理键开关（disable-model-invocation）覆盖该根后
  // "只读"名不副实——与 dsh 的 user-agents 内置根对齐，按普通可写来源对待。
  { key: 'agents', label: 'Agents', sub: '.agents/skills' },
]

/** Target directory name when installing a (possibly nested) skill name. */
function installDirName(fullName) {
  const parts = String(fullName === undefined || fullName === null ? '' : fullName).split('/')
  return parts[parts.length - 1]
}

/** Absolute path with the $HOME prefix folded to `~` (no username leaks in UI). */
function displayPath(p) {
  const home = homedir()
  if (p === home) return '~'
  if (p.startsWith(home + sep)) return '~' + p.slice(home.length)
  return p
}

function extractFrontmatter(content) {
  const lines = content.split(/\r?\n/)
  if (lines[0] === undefined || lines[0].trim() !== '---') return undefined
  const yamlLines = []
  for (let index = 1; index < lines.length; index += 1) {
    const line = lines[index]
    if (line.trim() === '---') return yamlLines.join('\n')
    yamlLines.push(line)
  }
  return undefined
}

function parseSkillMd(content) {
  const yamlText = extractFrontmatter(content)
  if (yamlText === undefined) return { meta: {}, body: content }
  let meta = {}
  try {
    const parsed = YAML.parse(yamlText)
    if (parsed !== null && typeof parsed === 'object') meta = parsed
  } catch {}
  const lines = content.split(/\r?\n/)
  let closer = -1
  for (let index = 1; index < lines.length; index += 1) {
    if (lines[index].trim() === '---') { closer = index; break }
  }
  const body = closer >= 0 ? lines.slice(closer + 1).join('\n').replace(/^\r?\n/, '') : content
  return { meta, body }
}

function buildEntry(root, dir, stat, linkTarget) {
  return { root, dir, relPath: relative(root, dir).split(sep).join('/'), stat, isLink: linkTarget !== undefined, linkTarget }
}

async function scanSkillDirs(root, current, out, visited) {
  let entries
  try { entries = await fsP.readdir(current, { withFileTypes: true }) }
  catch { return }
  for (const entry of entries) {
    if (MARKET_SCAN_SKIP.has(entry.name)) continue
    const dir = join(current, entry.name)
    // Follow symlinks: executor skills dirs routinely symlink entries from a
    // shared pool (~/.agents/skills); Dirent.isDirectory() would miss them.
    // lstat first so the entry can carry its linked-ness (UI marks such skills
    // as virtual); non-links reuse the lstat result and skip the second stat.
    let lst
    try { lst = await fsP.lstat(dir) } catch { continue }
    const linked = lst.isSymbolicLink()
    let dirStat = lst
    if (linked) {
      try { dirStat = await fsP.stat(dir) } catch { continue }
    }
    if (!dirStat.isDirectory()) continue
    let real
    try { real = await fsP.realpath(dir) } catch { continue }
    if (visited.has(real)) continue // symlink cycle guard
    visited.add(real)
    let hasSkillMd = false, skillMdStat
    try { skillMdStat = await fsP.stat(join(dir, 'SKILL.md')); hasSkillMd = skillMdStat.isFile() } catch { hasSkillMd = false }
    if (hasSkillMd) { out.push(buildEntry(root, dir, skillMdStat, linked ? real : undefined)) }
    else { await scanSkillDirs(root, dir, out, visited) }
  }
}

async function scanRoot(root) {
  const out = []
  let real
  try { await fsP.access(root) } catch { return out }
  try { real = await fsP.realpath(root) } catch { return out }
  await scanSkillDirs(root, root, out, new Set([real]))
  return out
}

async function readSkillEntry(entry) {
  const content = await fsP.readFile(join(entry.dir, 'SKILL.md'), 'utf8')
  const { meta, body } = parseSkillMd(content)
  const name = typeof meta.name === 'string' && meta.name !== '' ? meta.name : basename(entry.dir)
  return {
    entry,
    name,
    description: typeof meta.description === 'string' ? meta.description : '',
    keywords: Array.isArray(meta.keywords) ? meta.keywords : [],
    version: typeof meta.version === 'string' ? meta.version : undefined,
    author: typeof meta.author === 'string' ? meta.author : undefined,
    license: typeof meta.license === 'string' ? meta.license : undefined,
    meta, body,
    modifiedAt: entry.stat !== undefined ? entry.stat.mtime.toISOString() : undefined,
  }
}

async function countFilesAndSize(dir) {
  let fileCount = 0, totalSize = 0
  const walk = async (current) => {
    const entries = await fsP.readdir(current, { withFileTypes: true })
    for (const entry of entries) {
      const entryPath = join(current, entry.name)
      // stat follows symlinks so linked files/dirs count toward the skill
      let stat = await fsP.stat(entryPath).catch(() => undefined)
      if (stat === undefined) continue
      if (stat.isDirectory()) { await walk(entryPath) }
      else if (stat.isFile()) {
        fileCount += 1
        totalSize += stat.size
      }
    }
  }
  await walk(dir)
  return { fileCount, totalSize }
}

async function copyDir(from, to) {
  await fsP.mkdir(to, { recursive: true })
  const entries = await fsP.readdir(from, { withFileTypes: true })
  for (const entry of entries) {
    if (entry.name === '.git') continue
    const source = join(from, entry.name), target = join(to, entry.name)
    // Follow symlinks and materialize their targets: installs must be
    // self-contained (a linked references/ dir cannot dangle later).
    let stat
    try { stat = await fsP.stat(source) } catch { continue }
    if (stat.isDirectory()) { await copyDir(source, target) }
    else if (stat.isFile()) { await fsP.copyFile(source, target) }
  }
}

async function resolveSkillDir(root, fullName) {
  if (fullName === '' || fullName.includes('..') || fullName.includes('\\') || fullName.startsWith('/')) {
    throw new Error('invalid skill name')
  }
  const dir = resolve(root, fullName)
  if (!dir.startsWith(resolve(root) + sep)) throw new Error('invalid skill name: escapes root')
  let stat
  try { stat = await fsP.stat(join(dir, 'SKILL.md')) }
  catch (e) {
    if (e.code === 'ENOENT' || e.code === 'ENOTDIR') throw new Error(`skill '${fullName}' not found`)
    throw e
  }
  if (!stat.isFile()) throw new Error('not a skill directory')
  return dir
}

// ── Shared route helpers ────────────────────────────────────────────────

function validSkillName(name) {
  return typeof name === 'string' && name !== '' && !name.includes('..') && !name.includes('\\') && !name.startsWith('/')
}

/**
 * Resolve a skill dir under one source root by the identifier the client sends.
 * Tries the direct path `<root>/<name>` first (covers dir name == frontmatter
 * name, and nested relPaths like `grouped/foo`). On ENOENT, falls back to a
 * frontmatter-name scan: some sources ship a skill in a dir whose name ≠ its
 * frontmatter `name` (e.g. WorkBuddy's `dev-expert__skillhub/` whose frontmatter
 * `name` is `dev-expert`). The client lists & addresses such skills by their
 * frontmatter `name`, so the resolver must honor it. frontmatter `name` is always
 * single-segment kebab, so a slash-bearing request is a relPath that already
 * missed direct lookup and cannot be a frontmatter name — skip the scan.
 * Returns the skill dir or undefined.
 */
async function resolveSkillDirByName(root, name) {
  try { return await resolveSkillDir(root, name) }
  catch (e) {
    if (!String(e && e.message).includes('not found')) throw e
  }
  if (name.includes('/')) return undefined
  for (const entry of await scanRoot(root)) {
    try { if ((await readSkillEntry(entry)).name === name) return entry.dir }
    catch {}
  }
  return undefined
}

/** Resolve `<root>/<name>` to an existing skill dir under one source root. */
async function findDirUnderRoot(root, fullName, where) {
  const dir = await resolveSkillDirByName(root, fullName)
  if (dir === undefined) throw new Error(`skill '${fullName}' not found in ${where}`)
  return dir
}

async function sendSkillFile(res, skillDir, relPath, contentType) {
  const target = resolve(skillDir, relPath)
  const skillRoot = resolve(skillDir)
  if (!target.startsWith(skillRoot + sep)) throw new Error('invalid file path')
  const stat = await fsP.stat(target)
  if (!stat.isFile()) throw new Error('file not found')
  res.writeHead(200, {
    'content-type': contentType !== undefined && contentType !== '' ? contentType : 'application/octet-stream',
    'content-length': stat.size,
  })
  const stream = createReadStream(target)
  stream.pipe(res)
  await new Promise((fulfil, reject) => {
    stream.on('error', reject)
    res.on('close', () => fulfil())
    stream.on('end', () => fulfil())
  })
}

async function walkFiles(base, current, files = []) {
  const entries = await fsP.readdir(current, { withFileTypes: true })
  for (const entry of entries) {
    const entryPath = join(current, entry.name)
    let stat = await fsP.stat(entryPath).catch(() => undefined) // follows symlinks
    if (stat === undefined) continue
    if (stat.isDirectory()) { await walkFiles(base, entryPath, files) }
    else if (stat.isFile()) {
      files.push({ path: relative(base, entryPath).split(sep).join('/'), size: stat.size, modifiedAt: stat.mtime.toISOString() })
    }
  }
  return files
}

function readJsonBody(req) {
  return new Promise((fulfil, reject) => {
    let size = 0, chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > MAX_BODY_BYTES) { reject(new Error('request body too large')); req.destroy(); return }
      chunks.push(chunk)
    })
    req.on('end', () => {
      try { fulfil(chunks.length === 0 ? {} : JSON.parse(Buffer.concat(chunks).toString('utf8'))) }
      catch (error) { reject(new Error(`invalid JSON body: ${error && error.message}`)) }
    })
    req.on('error', reject)
  })
}

function sendJson(res, status, payload) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(payload))
}

function flagValue(meta, key) {
  const value = meta[key]
  if (typeof value === 'boolean') return value
  if (typeof value === 'string') {
    const lowered = value.trim().toLowerCase()
    if (['true', 'yes', 'on', '1'].includes(lowered)) return true
    if (['false', 'no', 'off', '0'].includes(lowered)) return false
  }
  return undefined
}

function invocationPolicy(meta) {
  return { modelInvocable: flagValue(meta, 'disable-model-invocation') !== true, userInvocable: flagValue(meta, 'user-invocable') !== false }
}

function truncateDescription(text) {
  if (typeof text !== 'string') return ''
  const single = text.split(/\r?\n/)[0]
  return single.length > DESCRIPTION_LIMIT ? single.slice(0, DESCRIPTION_LIMIT) + '…' : single
}

// ── 注入开销估算（≈token / 字符）─────────────────────────────────────────
// 技能注入模型 = 名称+描述，两个指标都按该文本统计（字符数即其长度，token 数
// 用 js-tiktoken 的 cl100k_base 词表估算——与 tiktokenizer 同词表同值）。列表
// 接口的 description 是截断展示，统计必须喂截断前的全文。DeepSeek 自有分词与
// tiktoken 有差异，数值用于横向比较而非精确计费；词表加载失败时降级为只出字符数。
let usageEncoder = null
let usageEncoderFailed = false
let usageEncoderOverride  // 测试注入点：undefined 走正常加载，null 强制降级
function usageEncoderLazy() {
  if (usageEncoderOverride !== undefined) return usageEncoderOverride
  if (usageEncoderFailed) return null
  if (usageEncoder === null) {
    try {
      const { Tiktoken } = require('js-tiktoken/lite')
      usageEncoder = new Tiktoken(require('js-tiktoken/ranks/cl100k_base'))
    } catch { usageEncoderFailed = true }
  }
  return usageEncoder
}
const USAGE_MEMO_CAP = 25000
const usageMemo = new Map()
function usageStat(name, description) {
  const desc = typeof description === 'string' ? description : ''
  const text = `${name || ''}\n${desc}`
  const stat = { chars: text.length }
  const enc = usageEncoderLazy()
  if (enc !== null) {
    let tokens = usageMemo.get(text)
    if (tokens === undefined) {
      tokens = enc.encode(text).length
      if (usageMemo.size >= USAGE_MEMO_CAP) usageMemo.clear()
      usageMemo.set(text, tokens)
    }
    stat.tokens = tokens
  }
  return stat
}

function expandTilde(p) {
  return p === '~' || p.startsWith('~/') || p.startsWith('~\\') ? join(homedir(), p.slice(2)) : p
}

/** dsh 数据根（与宿主一致：$DSH_HOME，缺省 ~/.dsh）。 */
function dshHome() {
  return process.env.DSH_HOME ? resolve(process.env.DSH_HOME) : join(homedir(), '.dsh')
}

/**
 * 切换 dsh 原生治理键 `disable-model-invocation`（docs/subsystems/skills.md）。
 * modelInvocable=true 时移除该键；false 时写入 true。其余 frontmatter 键与正文原样保留。
 */
function setModelInvocable(content, modelInvocable) {
  const lines = String(content || '').split(/\r?\n/)
  if (lines[0] === undefined || lines[0].trim() !== '---') {
    return modelInvocable ? content : `---\ndisable-model-invocation: true\n---\n\n${content}`
  }
  let closer = -1
  for (let i = 1; i < lines.length; i += 1) {
    if (lines[i].trim() === '---') { closer = i; break }
  }
  if (closer === -1) return content
  let kept = lines.slice(1, closer).filter((l) => !/^disable-model-invocation\s*:/.test(l.trim()))
  if (!modelInvocable) kept = [...kept, 'disable-model-invocation: true']
  return [...lines.slice(0, 1), ...kept, ...lines.slice(closer)].join('\n')
}

async function atomicWriteJs(file, content) {
  await fsP.mkdir(join(file, '..'), { recursive: true })
  const temp = join(join(file, '..'), `.${randomUUID()}.tmp`)
  await fsP.writeFile(temp, content, 'utf8')
  await fsP.rename(temp, file)
}

// ── Market git sync (ntd git_sync semantics: clone --depth 1 first, then
// fetch + reset --hard so the remote always wins and local damage heals) ──

function gitExec(binary, args, cwd) {
  return new Promise((fulfil, reject) => {
    execFile(binary, args, { cwd, timeout: 10 * 60 * 1000, maxBuffer: 16 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        const tail = String(stderr || error.message || '').split(/\r?\n/).filter(Boolean).slice(-3).join(' ')
        reject(new Error(`git ${args[0]}: ${tail || error.message}`))
        return
      }
      fulfil(String(stdout).trim())
    })
  })
}

async function gitAvailable(binary) {
  try { await gitExec(binary, ['--version']); return true } catch { return false }
}

async function gitCurrentCommit(binary, repo) {
  try { return await gitExec(binary, ['rev-parse', 'HEAD'], repo) } catch { return undefined }
}

async function gitRemoteCommit(binary, repo, remote, branch) {
  try {
    const out = await gitExec(binary, ['ls-remote', '--heads', remote, branch], repo)
    return out.split(/\s+/)[0] || undefined
  } catch { return undefined }
}

/** Embed an access token in an https remote URL (gitcode/oauth2 style).
 *  Credentials stay out of .git/config — every remote-touching command
 *  receives the authed URL directly and nothing is persisted. */
function authedUrl(url, token) {
  if (!token) return url
  return String(url).replace(/^(https?:\/\/)([^@/]+@)?/, `$1oauth2:${encodeURIComponent(token)}@`)
}

/** Clone (first time) or fetch+reset (update); remote branch is truth.
 *  `sparsePaths` (e.g. ['skills']) switches the checkout to sparse mode: fresh
 *  clones pass --filter=blob:none --sparse so only those subtrees download
 *  (the ntd-resource monorepo also carries experts/ + templates/, ~2x the
 *  skills payload); servers without filter support just warn and fall back to
 *  a full clone, which sparse-checkout still prunes. An existing full checkout
 *  is converted in place — the worktree prunes immediately, already-packed
 *  blobs stay (reachable from HEAD), so the big win is on fresh clones. */
async function gitSyncRepo(binary, url, branch, repoDir, token, sparsePaths) {
  const remote = authedUrl(url, token)
  const sparse = Array.isArray(sparsePaths) && sparsePaths.length > 0 ? sparsePaths : undefined
  let repoExists = false
  try { await fsP.access(join(repoDir, '.git')); repoExists = true } catch { repoExists = false }
  if (!repoExists) {
    await fsP.rm(repoDir, { recursive: true, force: true })
    await fsP.mkdir(join(repoDir, '..'), { recursive: true })
    if (sparse) {
      await gitExec(binary, ['clone', '-b', branch, '--depth', '1', '--filter=blob:none', '--sparse', remote, repoDir])
      await gitExec(binary, ['sparse-checkout', 'set', '--cone', ...sparse], repoDir)
    } else {
      await gitExec(binary, ['clone', '-b', branch, '--depth', '1', remote, repoDir])
    }
    return { isFirstClone: true, hasUpdates: true, before: undefined, after: await gitCurrentCommit(binary, repoDir) }
  }
  // Migrate a pre-sparse full checkout in place (idempotent no-op once sparse).
  if (sparse) {
    try { await gitExec(binary, ['sparse-checkout', 'set', '--cone', ...sparse], repoDir) }
    catch (e) { console.warn(`skills-management: sparse-checkout conversion failed, continuing full: ${e && e.message}`) }
  }
  const before = await gitCurrentCommit(binary, repoDir)
  await gitExec(binary, ['fetch', remote, branch], repoDir)
  await gitExec(binary, ['reset', '--hard', 'FETCH_HEAD'], repoDir)
  const after = await gitCurrentCommit(binary, repoDir)
  return { isFirstClone: false, hasUpdates: before !== after, before, after }
}

const DEFAULT_MARKET_SYNC = {
  url: 'https://gitcode.com/weibaohui/ntd-resource.git',
  branch: 'main',
  gitBinary: 'git',
  autoSync: true,        // periodic: sync when lastSyncAt is older than a day
  syncOnStartup: true,
  // 市场货架默认只进设置页浏览/安装，不进宿主 `/` 技能注册表——数千条
  // 「仅用户」候选会把 slash 菜单刷爆。false = 只保留已安装技能。
  publishMarket: false,
}

/** User-settings namespace persisted through the host ctx.settings service
 *  (local provider → $DSH_HOME/settings.yaml). Falls back to an in-memory
 *  override sheet when the service is absent (tests, minimal compositions). */
function marketSettingsSchema() {
  if (!Schema) return null
  return Schema.object({
    url: Schema.string(),
    branch: Schema.string(),
    gitBinary: Schema.string(),
    repoDir: Schema.string(),
    autoSync: Schema.boolean(),
    syncOnStartup: Schema.boolean(),
    publishMarket: Schema.boolean(),
    token: Schema.string(),
  })
}

// ── Executor（本机技能来源）运行时 sheet ─────────────────────────────────
// 内置表 EXECUTOR_DEFS 永远是默认值，这份 sheet 只存用户增量（目录覆盖 /
// 停用 / 新增），所以「恢复默认」= 清空整个 sheet。与 cordis 静态配置
// （executorDirs/disabledExecutors/extraExecutors）的优先级：cordis 最高。
function executorSettingsSchema() {
  if (!Schema) return null
  return Schema.object({
    dirs: Schema.dict(Schema.string()),      // 内置 key → 目录覆盖（dsh 锁定不接受）
    disabled: Schema.array(Schema.string()), // 停用的内置 key
    extra: Schema.array(Schema.object({      // 用户新增执行器
      key: Schema.string(),
      label: Schema.string(),
      dir: Schema.string(),
    })),
  })
}
const EXECUTOR_SHEET_DEFAULTS = Object.freeze({ dirs: {}, disabled: [], extra: [] })

// ── 0.1.7 settings 接线 ──
// settings 服务不再支持 ctx.settings.register（且一条插件 entry 只有一个 id）：
// 两个旧 scope（market / executors）合并为模块顶层导出的一个 volatile Config，
// marketSync / executorSheet 各为一个 volatile 子对象——volatile 节点的整棵子树
// 都可被设置 UI 投影与 ctx.settings.update 写回。读走 describe() 投影，写走
// ctx.settings.update('skills-management', { marketSync | executorSheet: … })，
// 持久化进 profile patch（重启不丢）。marketRepoDir 为旧版平铺配置兼容位。
let Config = null
try {
  // 兼容位（config.marketRepoDir）不进 Config——纯字符串字段经宿主投影会物化成
  // {}，反而毒化配置；patch 里的未知键本来就能透传，baseSettings 直接读即可。
  Config = Schema
    ? Schema.object({
      marketSync: marketSettingsSchema().volatile(),
      executorSheet: executorSettingsSchema().volatile(),
    })
    : null
} catch { /* schemastery <3.18.4 无 .volatile()：降级为无 Config（设置写回不可用），插件运行不受影响 */ }

// ── Share-run jobs: real execution via the official headless channel
// (`dsh --profile headless "<task>"`, cwd = the skill directory — the
// workspace, session and model loop are owned by that one-shot process). ──

function contentTypeFor(p) {
  const ext = p.slice(p.lastIndexOf('.') + 1).toLowerCase()
  const map = { md: 'text/markdown; charset=utf-8', txt: 'text/plain; charset=utf-8', json: 'application/json; charset=utf-8', js: 'text/javascript', mjs: 'text/javascript', ts: 'text/typescript', tsx: 'text/typescript', css: 'text/css', html: 'text/html', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', yaml: 'text/yaml', yml: 'text/yaml' }
  return map[ext]
}

module.exports = {
  name: 'skills-management',
  Config: Config ?? undefined,
  inject: ['skills', 'webServer', 'settings', 'agents', 'agentDefaultModel', 'sessions', 'connection'],
  __internals: { extractFrontmatter, parseSkillMd, invocationPolicy, installDirName, EXECUTOR_DEFS, usageStat, usageMemo, setUsageEncoderOverride: (v) => { usageEncoderOverride = v } },

  apply(ctx, config = {}) {
    // Explicit marketDirs config wins; otherwise the scan follows the
    // runtime-configurable repo dir (<repoDir>/skills) so moving the checkout
    // in settings switches the market without touching cordis.yml.
    const configMarketDirs = config.marketDirs !== undefined
      ? config.marketDirs.map((d) => resolve(expandTilde(d)))
      : undefined
    const effectiveRepoDir = () => {
      const eff = marketSettings()
      return resolve(expandTilde(
        typeof eff.repoDir === 'string' && eff.repoDir !== '' ? eff.repoDir
          : config.marketRepoDir !== undefined ? config.marketRepoDir
          : join(dshHome(), 'skills-management', 'market')))
    }
    const marketRoots = () => configMarketDirs !== undefined ? configMarketDirs : [join(effectiveRepoDir(), 'skills')]
    const marketDirs = marketRoots  // scan/install/locate call sites read through this
    // 稀疏检出子树：ntd-resource 仓库同时携带 experts/templates，只检 skills 一份省一半以上
    // 流量与磁盘。config.marketSparsePaths: null 关闭；自定义数组换目标子树。
    const marketSparsePaths = () => config.marketSparsePaths === null
      ? undefined
      : (Array.isArray(config.marketSparsePaths) && config.marketSparsePaths.length > 0 ? config.marketSparsePaths.map(String) : ['skills'])
    const installedDir = resolve(expandTilde(config.installedDir !== undefined ? config.installedDir : process.env.DSH_HOME ? join(process.env.DSH_HOME, 'skills') : join(homedir(), '.dsh', 'skills')))
    const providerName = config.providerName !== undefined ? config.providerName : 'ntd-skills'
    // 市场库存（数几千条）默认不进模型目录 available_skills —— 只作为可浏览/可安装的货架。
    // 装到用户库（installedDir）后才对模型可见。config.marketModelInvocable: true 可恢复旧行为。
    const marketModelInvocable = config.marketModelInvocable === true

    // ── Executor (on-machine source) rows ──
    // dsh first (its root is the installed library, locked); then known defs
    // minus disabled; then user extras. Rows are recomputed per request so
    // runtime edits (executor-settings API → settings.yaml) apply without a
    // restart. Per-key priority: cordis 静态配置 > runtime sheet > 默认表，
    // `executorDirs` overrides keep making scans testable without $HOME.
    const executorDirsOverride = config.executorDirs !== undefined && config.executorDirs !== null && typeof config.executorDirs === 'object' ? config.executorDirs : {}
    const disabledExecutors = new Set(Array.isArray(config.disabledExecutors) ? config.disabledExecutors : [])
    const cordisExtras = (Array.isArray(config.extraExecutors) ? config.extraExecutors : []).filter((e) => e !== null && typeof e === 'object')
    const executorSettingsOverrides = {} // 进程内兜底：写回缺席/失败时保本次运行一致
    const runtimeSheet = () => {
      const doc = (liveSettings && typeof liveSettings === 'object') ? liveSettings : {}
      const raw = (doc.executorSheet && typeof doc.executorSheet === 'object') ? doc.executorSheet : executorSettingsOverrides
      const v = raw && typeof raw === 'object' ? raw : {}
      return {
        dirs: v.dirs !== null && typeof v.dirs === 'object' && !Array.isArray(v.dirs) ? v.dirs : {},
        disabled: Array.isArray(v.disabled) ? v.disabled : [],
        extra: Array.isArray(v.extra) ? v.extra : [],
      }
    }
    const computeExecutorRows = () => {
      const sheet = runtimeSheet()
      const runtimeDisabled = new Set(sheet.disabled)
      const rows = []
      const seen = new Set()
      const pushExtra = (extra, locked) => {
        if (extra === null || typeof extra !== 'object') return
        if (typeof extra.key !== 'string' || extra.key === '') return
        if (typeof extra.dir !== 'string' || extra.dir === '') return
        if (seen.has(extra.key)) return
        seen.add(extra.key)
        rows.push({
          key: extra.key,
          label: typeof extra.label === 'string' && extra.label !== '' ? extra.label : extra.key,
          root: resolve(expandTilde(extra.dir)),
          readOnly: extra.readOnly === true,
          source: 'custom',
          locked: locked === true,
        })
      }
      for (const def of EXECUTOR_DEFS) {
        if (disabledExecutors.has(def.key) || runtimeDisabled.has(def.key)) continue
        let root
        if (def.key === 'dsh') root = installedDir
        else if (executorDirsOverride[def.key] !== undefined) root = resolve(expandTilde(String(executorDirsOverride[def.key])))
        else if (typeof sheet.dirs[def.key] === 'string' && sheet.dirs[def.key] !== '') root = resolve(expandTilde(sheet.dirs[def.key]))
        else root = def.sub !== undefined ? join(homedir(), ...def.sub.split('/')) : undefined
        if (seen.has(def.key)) continue
        seen.add(def.key)
        rows.push({ key: def.key, label: def.label, root, readOnly: def.readOnly === true, source: 'builtin', locked: def.key === 'dsh' })
      }
      for (const extra of cordisExtras) pushExtra(extra, true)
      for (const extra of sheet.extra) pushExtra(extra, false)
      return rows
    }
    /** 管理面板投影：全部内置（停用的也列，UI 置灰）+ 自定义，带可编辑性标记。 */
    const executorSheetProjection = () => {
      const sheet = runtimeSheet()
      const runtimeDisabled = new Set(sheet.disabled)
      const executors = []
      for (const def of EXECUTOR_DEFS) {
        const byConfig = executorDirsOverride[def.key] !== undefined
        const runtimeOverridden = typeof sheet.dirs[def.key] === 'string' && sheet.dirs[def.key] !== ''
        executors.push({
          key: def.key,
          label: def.label,
          source: 'builtin',
          locked: def.key === 'dsh',
          managedByConfig: byConfig,
          disabled: def.key !== 'dsh' && (disabledExecutors.has(def.key) || runtimeDisabled.has(def.key)),
          overridden: runtimeOverridden,
          defaultDir: def.key === 'dsh' ? displayPath(installedDir) : def.sub !== undefined ? '~/' + def.sub : '',
          dir: def.key === 'dsh'
            ? displayPath(installedDir)
            : byConfig ? displayPath(resolve(expandTilde(String(executorDirsOverride[def.key]))))
            : runtimeOverridden ? sheet.dirs[def.key]
            : def.sub !== undefined ? '~/' + def.sub : '',
        })
      }
      for (const extra of cordisExtras) {
        if (typeof extra.key !== 'string' || extra.key === '' || typeof extra.dir !== 'string' || extra.dir === '') continue
        executors.push({ key: extra.key, label: typeof extra.label === 'string' && extra.label !== '' ? extra.label : extra.key, source: 'custom', locked: false, managedByConfig: true, disabled: false, dir: extra.dir })
      }
      for (const extra of sheet.extra) {
        if (extra === null || typeof extra !== 'object') continue
        if (typeof extra.key !== 'string' || extra.key === '' || typeof extra.dir !== 'string' || extra.dir === '') continue
        executors.push({ key: extra.key, label: typeof extra.label === 'string' && extra.label !== '' ? extra.label : extra.key, source: 'custom', locked: false, managedByConfig: false, disabled: false, dir: extra.dir })
      }
      return executors
    }

    async function discoverAll() {
      const market = [], installed = []
      for (const root of marketDirs()) {
        for (const entry of await scanRoot(root)) {
          try { market.push(await readSkillEntry(entry)) }
          catch (e) { ctx.logger.warn(`skills-management: skipping ${entry.dir}: ${e && e.message}`) }
        }
      }
      for (const entry of await scanRoot(installedDir)) {
        try { installed.push(await readSkillEntry(entry)) }
        catch (e) { ctx.logger.warn(`skills-management: skipping ${entry.dir}: ${e && e.message}`) }
      }
      return { market, installed }
    }

    /**
     * 链接来源标注：技能目录是软链接时，把 realpath 目标匹配到某个执行器根
     * （最长前缀胜出），命中则给出该来源的 label（如 Agents），前端以此显示
     * 「链接 → Agents」而不是一串裸路径。执行器根先做 realpath——macOS 的
     * /var→/private/var 这类前缀软链接会让裸字符串比较失手。目标不在任何
     * 已知根内时返回 undefined，前端退回显示折叠后的目标路径。
     */
    const rootRealMemo = new Map()
    const realRoot = async (p) => {
      if (!rootRealMemo.has(p)) rootRealMemo.set(p, await fsP.realpath(p).catch(() => p))
      return rootRealMemo.get(p)
    }
    const linkExecutorLabel = async (target) => {
      let best
      for (const r of computeExecutorRows()) {
        if (typeof r.root !== 'string' || r.root === '') continue
        const rp = await realRoot(resolve(r.root))
        if (target !== rp && !target.startsWith(rp + sep)) continue
        if (best === undefined || rp.length > best.rp.length) best = { rp, label: r.label }
      }
      return best ? best.label : undefined
    }
    /** 列表/详情共用的链接字段包；非链接返回空对象（JSON 里不出现这些键）。 */
    const linkFields = async (isLink, target) => isLink === true && typeof target === 'string'
      ? { isLink: true, linkTarget: displayPath(target), linkExecutor: await linkExecutorLabel(target) }
      : {}

    /**
     * One executor row → summary + flat skill list (ntd `discover_skills_for`).
     * With `countsOnly` the expensive per-skill dir walks are skipped and
     * `skills` stays undefined — callers get `skillCount` only.
     */
    async function scanExecutor(row, countsOnly = false) {
      const summary = { key: row.key, label: row.label, dir: displayPath(row.root), dirExists: false, readOnly: row.readOnly, source: row.source, locked: row.locked === true, skillCount: 0 }
      if (!countsOnly) summary.skills = []
      try { await fsP.access(row.root) } catch { return summary }
      summary.dirExists = true
      for (const entry of await scanRoot(row.root)) {
        try {
          const read = await readSkillEntry(entry)
          // ntd naming: nested skill whose frontmatter name equals its dir
          // basename keeps the category path as display name.
          const listed = entry.relPath.includes('/') && read.name === basename(entry.dir) ? entry.relPath : read.name
          summary.skillCount += 1
          if (countsOnly) continue
          const { fileCount, totalSize } = await countFilesAndSize(entry.dir)
          summary.skills.push({ name: listed, relPath: entry.relPath, description: truncateDescription(read.description), keywords: read.keywords, version: read.version, author: read.author, fileCount, totalSize, modifiedAt: read.modifiedAt, modelInvocable: invocationPolicy(read.meta).modelInvocable, ...(await linkFields(entry.isLink, entry.linkTarget)), ...usageStat(listed, read.description) })
        } catch (e) { ctx.logger.warn(`skills-management: skipping ${entry.dir}: ${e && e.message}`) }
      }
      if (summary.skills !== undefined) {
        summary.skills.sort((a, b) => {
          const la = a.name.toLowerCase(), lb = b.name.toLowerCase()
          return la < lb ? -1 : la > lb ? 1 : 0
        })
      }
      return summary
    }

    function findExecutorRow(key) {
      return computeExecutorRows().find((row) => row.key === key)
    }

    /**
     * Locate a named skill dir either scoped to one executor source or via
     * the legacy auto path (installed library first, then markets).
     * Returns `{ dir, executorKey|null, isInstalled }`.
     */
    async function locateNamedSkillDir(name, executorKey) {
      if (executorKey !== undefined && executorKey !== null && executorKey !== '' && executorKey !== 'auto') {
        const row = findExecutorRow(executorKey)
        if (row === undefined) throw new Error(`unknown executor '${executorKey}'`)
        const dir = await findDirUnderRoot(row.root, name, `${row.label} (${row.key})`)
        return { dir, executorKey: row.key, isInstalled: row.key === 'dsh' }
      }
      try { return { dir: await resolveSkillDir(installedDir, name), executorKey: 'dsh', isInstalled: true } }
      catch { /* fall through to market roots */ }
      for (const root of marketDirs()) {
        try { return { dir: await resolveSkillDir(root, name), executorKey: null, isInstalled: false } }
        catch (e) { if (!String(e && e.message).includes('not found')) throw e }
      }
      throw new Error(`skill '${name}' not found`)
    }

    /** Copy any source skill dir into the dsh user library and refresh. */
    async function copyIntoLibrary(sourceDir, shortName, overwrite) {
      const target = join(installedDir, shortName)
      if (!overwrite) {
        try { await fsP.access(target); throw new Error(`skill '${shortName}' already installed`) }
        catch (e) { if (e.code !== 'ENOENT') throw e }
      } else { await fsP.rm(target, { recursive: true, force: true }) }
      await copyDir(sourceDir, target)
      invalidate()
      return { name: shortName, path: target }
    }

    async function installMarketSkill(fullName, overwrite) {
      let sourceDir
      for (const root of marketDirs()) {
        try { sourceDir = await resolveSkillDir(root, fullName); break }
        catch (e) { if (!String(e && e.message).includes('not found')) throw e }
      }
      if (sourceDir === undefined) throw new Error(`skill '${fullName}' not found in market`)
      return copyIntoLibrary(sourceDir, installDirName(fullName), overwrite)
    }

    async function installFromExecutor(executorKey, fullName, overwrite) {
      const row = findExecutorRow(executorKey)
      if (row === undefined) throw new Error(`unknown executor '${executorKey}'`)
      const sourceDir = await findDirUnderRoot(row.root, fullName, `${row.label} (${row.key})`)
      return copyIntoLibrary(sourceDir, installDirName(fullName), overwrite)
    }

    async function deleteSkill(name, executorKey) {
      if (!validSkillName(name)) throw new Error('invalid skill name')
      const key = executorKey === undefined || executorKey === null || executorKey === '' ? 'dsh' : executorKey
      const row = findExecutorRow(key)
      if (row === undefined) throw new Error(`unknown executor '${key}'`)
      if (row.readOnly) throw new Error(`source '${key}' is read-only; cannot delete skills there`)
      const target = await resolveSkillDirByName(row.root, name)
      if (target === undefined) throw new Error(`skill '${name}' not found in ${row.label} (${row.key})`)
      await fsP.rm(target, { recursive: true })
      if (key === 'dsh') invalidate()
      return { removed: name, executor: key }
    }

    // ── Market sync state (persisted next to the repo root) ──
    const marketStateFile = join(resolve(installedDir, '..'), 'skills-market-sync.json')
    let marketState = { lastSyncAt: undefined, lastResult: undefined }
    // User-facing settings live in the host settings service when present;
    // the local json only carries runtime sync bookkeeping.
    const settingsOverrides = {}  // 进程内兜底（market 同步设置）
    const marketStateLoaded = fsP.readFile(marketStateFile, 'utf8')
      .then(raw => {
        const parsed = JSON.parse(raw)
        marketState = { lastSyncAt: parsed.lastSyncAt, lastResult: parsed.lastResult }
        // one-time migration: pre-settings-service overrides move into the
        // settings namespace, then are blanked in the legacy file
        if (parsed.settings && typeof parsed.settings === 'object' && Object.keys(parsed.settings).length > 0) {
          const legacy = parsed.settings
          Promise.resolve().then(async () => {
            await marketStateLoaded
            if (ctx.settings && typeof ctx.settings.update === 'function') {
              try {
                await ctx.settings.update('skills-management', { marketSync: legacy })
                await fsP.writeFile(marketStateFile, JSON.stringify(marketState, null, 2), { mode: 0o600 })
              } catch (e) { ctx.logger.warn(`skills-management: legacy settings migration: ${e && e.message}`) }
            } else {
              Object.assign(settingsOverrides, legacy)
            }
          })
        }
      })
      .catch(() => {})
    const baseSettings = () => {
      const cfg = (config.marketSync && typeof config.marketSync === 'object') ? config.marketSync : {}
      const base = { ...DEFAULT_MARKET_SYNC }
      for (const key of ['url', 'branch', 'gitBinary', 'autoSync', 'syncOnStartup', 'publishMarket']) {
        if (cfg[key] !== undefined) base[key] = cfg[key]
      }
      // 0.1.7 config 回写/投影可能给出 null 等非字符串值：类型不对就走默认，别让激活崩掉
      if (config.marketRepoDir !== undefined && config.marketRepoDir !== null && typeof config.marketRepoDir === 'string' && config.marketRepoDir !== '') {
        base.repoDir = resolve(expandTilde(config.marketRepoDir))
      }
      return base
    }
    function readDescriptor() {
      try {
        if (!ctx.settings || typeof ctx.settings.describe !== 'function') return null
        return ctx.settings.describe().find((x) => x.ns === 'skills-management') || null
      } catch { return null }
    }
    let liveSettings = {} // settings 文档实时值（document-updated 事件驱动刷新）
    // apply 时 loader 可能尚未就绪（describe 投影里还没有本插件条目），间隔重试
    function refreshLive(attempt = 0) {
      const d = readDescriptor()
      if (d) {
        if (d.value && typeof d.value === 'object') liveSettings = d.value
        return
      }
      if (attempt < 15) setTimeout(() => { refreshLive(attempt + 1) }, 2000).unref?.()
    }
    refreshLive()

    // settings 文档变更（dsh 自动生成的设置页、本插件面板写回）刷新实时值
    try {
      if (ctx.on && typeof ctx.on === 'function') {
        ctx.effect(() => {
          const off = ctx.on('settings/document-updated', (ns) => {
            if (ns !== 'skills-management') return
            const d = readDescriptor()
            if (d && d.value && typeof d.value === 'object') liveSettings = d.value
          })
          return () => { try { off() } catch {} }
        }, 'skills-management: settings watch')
      }
    } catch { /* 事件订阅不可用：写回后靠 overrides 维持本次运行 */ }
    const saveMarketState = async () => {
      // 0600: the state file may carry the access token
      try { await fsP.writeFile(marketStateFile, JSON.stringify(marketState, null, 2), { mode: 0o600 }) } catch {}
      try { await fsP.chmod(marketStateFile, 0o600) } catch {}
    }
    const marketSettings = () => {
      const doc = (liveSettings && typeof liveSettings === 'object') ? liveSettings : {}
      const docSync = (doc.marketSync && typeof doc.marketSync === 'object') ? doc.marketSync : {}
      const out = { ...baseSettings(), ...docSync, ...settingsOverrides }
      if (doc.marketRepoDir !== undefined && doc.marketRepoDir !== null && doc.marketRepoDir !== '') {
        out.repoDir = resolve(expandTilde(String(doc.marketRepoDir)))
      }
      return out
    }

    let marketSyncRun = null
    // 注入开销预热：后台把市场技能的 token 统计预先算进 usageStat 的 memo
    // （分块让出事件循环），避免首次打开市场列表时同步编码 6400 条描述
    // （~3s）拖慢首屏。市场同步会改内容，成功路径末尾再次触发。
    let usageWarmSeq = 0
    const warmUsageMemo = async () => {
      const seq = ++usageWarmSeq
      if (usageEncoderLazy() === null) return // 降级模式 memo 永远不命中，预热扫描是纯浪费
      try {
        const { market } = await discoverAll()
        for (let i = 0; i < market.length; i++) {
          if (seq !== usageWarmSeq) return
          usageStat(market[i].name, market[i].description)
          if (i % 500 === 499) await new Promise((r) => setImmediate(r))
        }
      } catch { /* 预热是尽力而为：miss 的条目由列表路由现算兜底 */ }
    }
    const runMarketSync = async () => {
      if (marketSyncRun !== null) return marketSyncRun
      marketSyncRun = (async () => {
        await marketStateLoaded
        const eff = marketSettings()
        const ok = await gitAvailable(eff.gitBinary)
        if (!ok) throw new Error('git is not available on PATH')
        const started = Date.now()
        const repoDir = effectiveRepoDir()
        const result = await gitSyncRepo(eff.gitBinary, eff.url, eff.branch, repoDir, eff.token, marketSparsePaths())
        marketState.lastSyncAt = new Date().toISOString()
        marketState.lastResult = { ...result, at: marketState.lastSyncAt, durationMs: Date.now() - started }
        await saveMarketState()
        invalidate()
        warmUsageMemo()
        return { ...marketState.lastResult, url: eff.url, branch: eff.branch, dir: repoDir }
      })().finally(() => { marketSyncRun = null })
      return marketSyncRun
    }

    // Startup + periodic auto-sync (fire-and-forget; failures only warn)
    ctx.effect(() => {
      const eff = marketSettings()
      if (eff.syncOnStartup) {
        marketStateLoaded.then(() => runMarketSync()).catch(e => ctx.logger.warn(`skills-management: startup market sync: ${e && e.message}`))
      }
      const timer = setInterval(() => {
        const now = Date.now()
        const eff2 = marketSettings()
        if (!eff2.autoSync) return
        const last = marketState.lastSyncAt ? Date.parse(marketState.lastSyncAt) : 0
        if (now - last > 24 * 3600 * 1000) {
          runMarketSync().catch(e => ctx.logger.warn(`skills-management: auto market sync: ${e && e.message}`))
        }
      }, 6 * 3600 * 1000)
      if (typeof timer.unref === 'function') timer.unref()
      return () => clearInterval(timer)
    }, 'skills-management: market auto-sync')

    // 激活后延迟预热 token 统计（给启动路径让路；unref 不拖住退出）
    ctx.effect(() => {
      const timer = setTimeout(() => { warmUsageMemo() }, 3000)
      if (typeof timer.unref === 'function') timer.unref()
      return () => { usageWarmSeq += 1; clearTimeout(timer) }
    }, 'skills-management: usage memo warm-up')

    const shareRunJobs = new Map()
    // Same-process Agent services（静态注入：apply 时已就绪；动态 ctx.inject 在
    // apply 内不触发是平台 gotcha）。
    const shareServices = { agents: ctx.agents, agentDefaultModel: ctx.agentDefaultModel, sessions: ctx.sessions }
    let providerControl
    const invalidate = () => { if (providerControl !== undefined) providerControl.invalidate() }

    ctx.skills.registerProvider((control) => {
      providerControl = control
      control.signal.addEventListener('abort', () => { if (providerControl === control) providerControl = undefined }, { once: true })
      return {
        name: providerName,
        async list() {
          const { market, installed } = await discoverAll()
          const candidates = []
          // Fail-soft: the registry throws — and kills the requesting session's
          // turn — on candidates that fail harness validation (empty
          // description, non-kebab-case name). Market checkouts with malformed
          // frontmatter trigger both routinely, so pre-filter here.
          const isValid = (row) => {
            if (!row.name || !KEBAB_NAME_RE.test(row.name)) return `invalid name '${row.name}'`
            if (!row.description || row.description.trim() === '') return 'empty description'
            return undefined
          }
          for (const row of installed) {
            const why = isValid(row)
            if (why !== undefined) {
              ctx.logger.warn(`skills-management: skipping installed skill '${row.name}' (${row.entry.dir}): ${why}`)
              continue
            }
            candidates.push(toCandidate(row, 'user-installed', RANK_INSTALLED))
          }
          // 市场货架默认不进宿主注册表（publishMarket: false）：数千条候选会把
          // `/` 菜单刷爆，且它们本就不该进模型目录。设置页浏览/安装不受影响。
          if (marketSettings().publishMarket !== false) {
            for (const row of market) {
              const why = isValid(row)
              if (why !== undefined) {
                ctx.logger.warn(`skills-management: skipping market skill '${row.entry.relPath}': ${why}`)
                continue
              }
              const shortName = row.name.includes('/') ? row.name.split('/').pop() : row.name
              if (installed.some((e) => e.name === shortName)) continue
              candidates.push(toCandidate(row, 'market', RANK_MARKET, { modelInvocable: marketModelInvocable }))
            }
          }
          return candidates
        },
        async get(candidate) {
          const entry = candidate.locator
          try {
            const row = await readSkillEntry({ ...entry, stat: entry.stat ?? (await fsP.stat(join(entry.dir, 'SKILL.md'))) })
            const invocation = candidate.source === 'market' && !marketModelInvocable
              ? { modelInvocable: false, userInvocable: true }
              : invocationPolicy(row.meta)
            return { name: row.name, description: row.description, whenToUse: typeof row.meta.whenToUse === 'string' ? row.meta.whenToUse : undefined, invocation, source: candidate.source, provider: providerName, resourceBase: { kind: 'directory', path: entry.dir }, content: row.body, path: join(entry.dir, 'SKILL.md'), metadata: row.meta }
          } catch { return undefined }
        },
      }
    })

    // `invocationOverride.modelInvocable` 为 false 时该候选不进模型目录（available_skills），
    // 但保留 userInvocable（UI 浏览 / 用户命令调用不受影响）。
    function toCandidate(row, source, rank, invocationOverride) {
      const base = invocationPolicy(row.meta)
      const invocation = invocationOverride ? { ...base, ...invocationOverride } : base
      return { name: row.name, description: row.description, invocation, source, provider: providerName, rank, locator: { dir: row.entry.dir, root: row.entry.root, relPath: row.entry.relPath, stat: row.entry.stat }, path: join(row.entry.dir, 'SKILL.md'), metadata: row.meta, whenToUse: typeof row.meta.whenToUse === 'string' ? row.meta.whenToUse : undefined, resourceBase: { kind: 'directory', path: row.entry.dir } }
    }

    ctx.effect(() => ctx.webServer.register({
      kind: 'prefix',
      path: '/skills-management/api',
      handler: async (req, res) => {
        try {
          // 与其它 host 路由一致的信任栅栏：connection 服务的 Host/Origin 检查
          // 加浏览器认证。缺了它，下面每个路由都能被任意网页跨站调用。
          const rejection = ctx.connection.requestRejection(req)
          if (rejection !== undefined) {
            res.writeHead(rejection)
            res.end()
            return
          }
          const url = new URL(req.url || '/', 'http://dsh.local')
          const apiPath = url.pathname.replace(/\/+$/, '')
          const query = url.searchParams

          // GET /skills-management/api/market/status
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/market/status')) {
            await marketStateLoaded
            const eff = marketSettings()
            const repoDir = effectiveRepoDir()
            const repoExists = await fsP.access(join(repoDir, '.git')).then(() => true).catch(() => false)
            const ok = await gitAvailable(eff.gitBinary)
            const [localCommit, remoteCommit] = repoExists && ok
              ? [await gitCurrentCommit(eff.gitBinary, repoDir), await gitRemoteCommit(eff.gitBinary, repoDir, 'origin', eff.branch)]
              : [undefined, undefined]
            sendJson(res, 200, {
              url: eff.url, branch: eff.branch, dir: displayPath(repoDir),
              gitAvailable: ok, repoExists,
              localCommit, remoteCommit,
              needsUpdate: localCommit !== undefined && remoteCommit !== undefined ? localCommit !== remoteCommit : undefined,
              lastSyncAt: marketState.lastSyncAt, lastResult: marketState.lastResult,
              autoSync: eff.autoSync, syncOnStartup: eff.syncOnStartup,
              publishMarket: eff.publishMarket !== false,
              hasToken: typeof eff.token === 'string' && eff.token !== '',
              syncing: marketSyncRun !== null,
              sparsePaths: marketSparsePaths() ?? null,
              settingsFile: join(dshHome(), 'settings.yaml'),
            })
            return
          }

          // POST /skills-management/api/market/sync
          if (req.method === 'POST' && apiPath.endsWith('/skills-management/api/market/sync')) {
            try {
              const result = await runMarketSync()
              sendJson(res, 200, result)
            } catch (e) { sendJson(res, 400, { error: String(e && e.message || e) }) }
            return
          }

          // PUT /skills-management/api/market/settings {url?, branch?, autoSync?, syncOnStartup?, publishMarket?}
          if (req.method === 'PUT' && apiPath.endsWith('/skills-management/api/market/settings')) {
            // body first: readJsonBody attaches listeners synchronously, so no
            // event can slip past while the state-file promise resolves
            const body = await readJsonBody(req)
            await marketStateLoaded
            const patch = {}
            for (const key of ['url', 'branch', 'gitBinary']) {
              if (typeof body[key] === 'string' && body[key] !== '') patch[key] = body[key]
            }
            // token: non-empty string sets it; null or '' clears it. Never echoed.
            let clearToken = false
            if (typeof body.token === 'string' && body.token !== '') patch.token = body.token
            if (body.token === null || body.token === '') clearToken = true
            if (typeof body.repoDir === 'string' && body.repoDir !== '') {
              patch.repoDir = resolve(expandTilde(body.repoDir))
            }
            for (const key of ['autoSync', 'syncOnStartup', 'publishMarket']) {
              if (typeof body[key] === 'boolean') patch[key] = body[key]
            }
            if (clearToken) delete settingsOverrides.token
            else Object.assign(settingsOverrides, patch)
            // 0.1.7 持久化：平铺 patch 挂进 marketSync: 子对象；token 清空走 mutate.unset
            if (ctx.settings && typeof ctx.settings.update === 'function') {
              try {
                if (Object.keys(patch).length > 0) await ctx.settings.update('skills-management', { marketSync: patch })
                if (clearToken) await ctx.settings.mutate('skills-management', [{ op: 'unset', path: ['marketSync', 'token'] }])
              } catch (e) { ctx.logger.warn(`skills-management: settings update 失败（仅本次运行生效）: ${e && e.message}`) }
            }
            // publishMarket 直接决定 provider.list() 的候选集合，改完立刻让
            // `/` 菜单重读注册表，不必等 skills/change 或重启。
            if ('publishMarket' in patch) invalidate()
            const eff = marketSettings()
            const { token, ...safe } = eff  // token 只写不回读
            sendJson(res, 200, { settings: safe, hasToken: typeof token === 'string' && token !== '', settingsFile: join(dshHome(), 'settings.yaml') })
            return
          }

          // GET /skills-management/api/executor-settings → 执行器目录管理面板：
          // 全部内置（停用的也在，UI 置灰）+ 自定义，带每行可编辑性标记。
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/executor-settings')) {
            sendJson(res, 200, { executors: executorSheetProjection(), settingsFile: join(dshHome(), 'settings.yaml') })
            return
          }

          // PUT /skills-management/api/executor-settings — body 就是下一份运行时
          // sheet {dirs, disabled, extra}。走 replace 整体替换（update 深合并
          // 删不掉 dict 里的键，恢复默认/删除行都需要整体覆写）；校验失败抛错 →
          // 外层 catch 回 400，持久化发生在校验通过之后。
          if (req.method === 'PUT' && apiPath.endsWith('/skills-management/api/executor-settings')) {
            const body = await readJsonBody(req)
            const dirs = {}
            if (body.dirs !== undefined && body.dirs !== null) {
              if (typeof body.dirs !== 'object' || Array.isArray(body.dirs)) throw new Error('dirs must be an object of executor key → directory')
              for (const [key, value] of Object.entries(body.dirs)) {
                if (key === 'dsh') throw new Error("executor 'dsh' is locked: its root is the installed skill library")
                if (!EXECUTOR_DEFS.some((d) => d.key === key)) throw new Error(`unknown executor '${key}'`)
                if (typeof value !== 'string' || value.trim() === '') throw new Error(`dir for '${key}' must be a non-empty string`)
                dirs[key] = value.trim()
              }
            }
            const disabled = []
            if (body.disabled !== undefined && body.disabled !== null) {
              if (!Array.isArray(body.disabled)) throw new Error('disabled must be an array of executor keys')
              for (const item of body.disabled) {
                const key = String(item)
                if (key === 'dsh') throw new Error("executor 'dsh' cannot be disabled")
                if (!EXECUTOR_DEFS.some((d) => d.key === key)) throw new Error(`unknown executor '${key}'`)
                disabled.push(key)
              }
            }
            const extra = []
            if (body.extra !== undefined && body.extra !== null) {
              if (!Array.isArray(body.extra)) throw new Error('extra must be an array of {key, label, dir}')
              for (const item of body.extra) {
                if (item === null || typeof item !== 'object') throw new Error('extra entries must be objects')
                const key = typeof item.key === 'string' ? item.key.trim() : ''
                if (!KEBAB_NAME_RE.test(key)) throw new Error(`executor key '${key || '(empty)'}' must be kebab-case (a-z 0-9 -)`)
                if (EXECUTOR_DEFS.some((d) => d.key === key) || extra.some((e) => e.key === key)) throw new Error(`executor key '${key}' already exists`)
                if (typeof item.dir !== 'string' || item.dir.trim() === '') throw new Error(`dir for '${key}' must be a non-empty string`)
                extra.push({ key, label: typeof item.label === 'string' && item.label.trim() !== '' ? item.label.trim() : key, dir: item.dir.trim() })
              }
            }
            const section = { dirs, disabled, extra }
            Object.assign(executorSettingsOverrides, section)
            // 0.1.7 持久化：sheet 是全量提交，先 unset 再 set，避免深层 merge 残留已删除的键
            if (ctx.settings && typeof ctx.settings.update === 'function') {
              try {
                await ctx.settings.mutate('skills-management', [
                  { op: 'unset', path: ['executorSheet'] },
                  { op: 'set', path: ['executorSheet'], value: section },
                ])
              } catch (e) { ctx.logger.warn(`skills-management: executor sheet update 失败（仅本次运行生效）: ${e && e.message}`) }
            }
            sendJson(res, 200, { executors: executorSheetProjection(), settingsFile: join(dshHome(), 'settings.yaml') })
            return
          }

          // POST /skills-management/api/share/run {prompt, dir} → real headless run
          if (req.method === 'POST' && apiPath.endsWith('/skills-management/api/share/run')) {
            const body = await readJsonBody(req)
            if (typeof body.prompt !== 'string' || body.prompt.trim() === '') { sendJson(res, 400, { error: 'body must provide prompt' }); return }
            if (typeof body.dir !== 'string' || body.dir === '') { sendJson(res, 400, { error: 'body must provide dir' }); return }
            const dir = resolve(expandTilde(body.dir))
            const stat = await fsP.stat(dir).catch(() => undefined)
            if (stat === undefined || !stat.isDirectory()) { sendJson(res, 400, { error: `dir not found: ${displayPath(dir)}` }); return }
            const binary = process.env.SKILLS_DSH_BIN || 'dsh'
            const job = createShareRunJob({ binary, prompt: body.prompt, dir, jobs: shareRunJobs, logger: ctx.logger, services: shareServices })
            sendJson(res, 202, { jobId: job.id, status: job.status })
            return
          }

          // GET /skills-management/api/share/run?id= → job status/output
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/share/run')) {
            const id = query.get('id') || ''
            const job = shareRunJobs.get(id)
            if (job === undefined) { sendJson(res, 404, { error: 'job not found' }); return }
            sendJson(res, 200, { ...job, output: job.output.slice(-32 * 1024) })
            return
          }

          // GET /skills-management/api/executors → on-machine sources.
          // Variants: ?mode=summary (counts only, no skill arrays) and
          // ?executor=<key> (one source, full list — lazy drill-in).
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/executors')) {
            const scopeKey = query.get('executor')
            if (scopeKey !== null && scopeKey !== '') {
              const scoped = findExecutorRow(scopeKey)
              if (scoped === undefined) throw new Error(`unknown executor '${scopeKey}'`)
              sendJson(res, 200, { executor: await scanExecutor(scoped) })
              return
            }
            const countsOnly = query.get('mode') === 'summary'
            const executors = []
            for (const row of computeExecutorRows()) executors.push(await scanExecutor(row, countsOnly))
            sendJson(res, 200, { executors })
            return
          }

          // GET /skills-management/api → list
          if (req.method === 'GET' && apiPath === '/skills-management/api') {
            const { market, installed } = await discoverAll()
            const sources = new Map()
            for (const row of market) {
              const sourceKey = row.entry.relPath.split('/')[0]
              const agg = sources.get(sourceKey) ?? { source: sourceKey, skills: 0, displayName: sourceKey }
              agg.skills += 1
              sources.set(sourceKey, agg)
            }
            const installedNames = new Set(installed.map((r) => r.name))
            sendJson(res, 200, {
              sources: [...sources.values()],
              market: market.map((row) => ({ name: row.entry.relPath, shortName: row.name, source: row.entry.relPath.split('/')[0], description: truncateDescription(row.description), keywords: row.keywords, version: row.version, installed: installedNames.has(row.name), totalSize: 0, ...usageStat(row.name, row.description) })),
              installed: await Promise.all(installed.map(async (row) => { const { fileCount, totalSize } = await countFilesAndSize(row.entry.dir); return { name: row.name, description: truncateDescription(row.description), path: row.entry.dir, fileCount, totalSize, modifiedAt: row.modifiedAt, ...usageStat(row.name, row.description) } })),
            })
            return
          }

          // GET /skills-management/api/detail?name=&executor= → detail
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/detail')) {
            const name = query.get('name') || ''
            const located = await locateNamedSkillDir(name, query.get('executor'))
            const content = await fsP.readFile(join(located.dir, 'SKILL.md'), 'utf8')
            const files = await walkFiles(located.dir, located.dir)
            const { fileCount, totalSize } = await countFilesAndSize(located.dir)
            const { meta, body } = parseSkillMd(content)
            const usage = usageStat(typeof meta.name === 'string' && meta.name !== '' ? meta.name : basename(name), meta.description)
            // 详情同样标注软链接（列表行经 scanRoot 自带；这里按定位到的目录现查）
            let linked = false, linkReal
            try {
              const lst = await fsP.lstat(located.dir)
              if (lst.isSymbolicLink()) { linked = true; linkReal = await fsP.realpath(located.dir) }
            } catch {}
            sendJson(res, 200, { name, shortName: basename(name), dir: displayPath(located.dir), executor: located.executorKey, isInstalled: located.isInstalled, ...(await linkFields(linked, linkReal)), content: body, contentWithMeta: content, meta, files, fileCount, totalSize, modifiedAt: files[0]?.modifiedAt, ...usage })
            return
          }

          // GET /skills-management/api/file?name=&path=&executor= → file content
          if (req.method === 'GET' && apiPath.endsWith('/skills-management/api/file')) {
            const name = query.get('name') || '', filePath = query.get('path') || ''
            const located = await locateNamedSkillDir(name, query.get('executor'))
            await sendSkillFile(res, located.dir, filePath, contentTypeFor(filePath))
            return
          }

          // POST /skills-management/api/install {name, from?, overwrite?}
          if (req.method === 'POST' && apiPath.endsWith('/skills-management/api/install')) {
            const body = await readJsonBody(req)
            if (typeof body.name !== 'string' || body.name === '') { sendJson(res, 400, { error: 'body must provide name' }); return }
            const result = typeof body.from === 'string' && body.from !== '' && body.from !== 'market'
              ? await installFromExecutor(body.from, body.name, body.overwrite === true)
              : await installMarketSkill(body.name, body.overwrite === true)
            sendJson(res, 201, { installed: { ...result, from: typeof body.from === 'string' && body.from !== '' && body.from !== 'market' ? body.from : 'market' } })
            return
          }

          // DELETE /skills-management/api {name, executor?} → remove
          if (req.method === 'DELETE' && apiPath.endsWith('/skills-management/api')) {
            const body = await readJsonBody(req)
            if (typeof body.name !== 'string' || body.name === '') { sendJson(res, 400, { error: 'body must provide name' }); return }
            sendJson(res, 200, await deleteSkill(body.name, typeof body.executor === 'string' ? body.executor : undefined))
            return
          }

          // PUT /skills-management/api/invocation {name, modelInvocable} → 治理键开关
          // dsh 原生 frontmatter 键（docs/subsystems/skills.md）：disable-model-invocation。
          // 解析范围：用户库（dsh）优先，找不到再查 ~/.agents/skills——dsh 的
          // skill-filesystem 把 user-agents 作为内置根全量扫进模型目录，这个开关
          // 同样管得住它们（其他键原样保留；写完靠宿主 watcher 失效，无需 invalidate）。
          if (req.method === 'PUT' && apiPath.endsWith('/skills-management/api/invocation')) {
            const body = await readJsonBody(req)
            if (typeof body.name !== 'string' || body.name === '') { sendJson(res, 400, { error: 'body must provide name' }); return }
            if (typeof body.modelInvocable !== 'boolean') { sendJson(res, 400, { error: 'body must provide modelInvocable boolean' }); return }
            // 与 dsh skill-filesystem 的 user-agents 根同款解析
            const agentsSkillsRoot = process.env.DSH_AGENTS_HOME !== undefined && process.env.DSH_AGENTS_HOME !== ''
              ? join(resolve(expandTilde(process.env.DSH_AGENTS_HOME)), 'skills')
              : join(homedir(), '.agents', 'skills')
            let skillDir
            let rootKey = 'dsh'
            try { skillDir = await resolveSkillDir(installedDir, body.name) }
            catch { skillDir = await resolveSkillDir(agentsSkillsRoot, body.name); rootKey = 'agents' }
            const file = join(skillDir, 'SKILL.md')
            const updated = setModelInvocable(await fsP.readFile(file, 'utf8'), body.modelInvocable)
            await atomicWriteJs(file, updated)
            invalidate()
            sendJson(res, 200, { name: body.name, modelInvocable: body.modelInvocable, root: rootKey })
            return
          }

          sendJson(res, 404, { error: 'not found' })
        } catch (error) { sendJson(res, 400, { error: String(error && error.message || error) }) }
      },
    }), 'skills-management: api route')
  },
}
