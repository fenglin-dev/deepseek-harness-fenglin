/**
 * dsh-liangshen — LiangShen (梁神) agent preset plugin.
 *
 * Host half only: on startup it syncs the bundled `presets/` tree into the
 * harness-home agent-presets root (`~/.dsh/.agent-presets`), making the
 * LiangShen preset selectable for new sessions without copying files by hand.
 * The capability announcement is a system-prompt section that ships OFF by
 * default (`announceToAgent: false`) and can be enabled in the web settings
 * surface (plugin config) or the profile patch. No browser half, no routes,
 * no agent tools — the preset itself provides the tools.
 *
 * The preset combines a minimal persona with a staged, promoted tool surface:
 * the system prompt keeps a minimal persona with standing working discipline
 * and workspace instructions, the session's entire first user turn runs a native
 * foundational tool surface ([bash, str_replace_editor, exit_plan_mode, skill],
 * with bash-only preserved as a configuration experiment), and from the second
 * turn this session presents its tools in PTC mode upon successful activation,
 * so the wire carries the single `run_code` transport while the generated SDK
 * bindings and collapse rule travel in the tool list injected as a durable
 * message after the user's message, preserving full input and output key
 * parameter semantics.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SettingsNamespace } from '@deepseek-ai/dsh-settings';
import z from 'schemastery';
/** Stable cordis plugin name. */
export declare const name = "liangshen";
/** Settings namespace of the plugin (the web settings surface edits it). */
export declare const LIANGSHEN_SETTINGS_NAMESPACE: SettingsNamespace;
/** Prompt assembly must exist before the announcement section can register. */
export declare const inject: string[];
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /** Master switch: when false, neither sync nor announcement runs. */
    enabled?: boolean;
    /** When true, a system-prompt section announces the plugin (default false — keep prompts clean unless the user opts in). */
    announceToAgent?: boolean;
}
export declare const Config: z<Config>;
/** Model-facing announcement: plugin presence, principle, and limits. */
export declare const LIANGSHEN_GUIDANCE = "\u672C\u673A\u5DF2\u5B89\u88C5 dsh-liangshen \u63D2\u4EF6\uFF08\u6881\u795E\u6A21\u5F0F agent preset\uFF09\uFF1A\u65B0\u5EFA\u4F1A\u8BDD\u7684\u9884\u8BBE\u9009\u62E9\u5668\u4E2D\u53EF\u9009\u300C\u6881\u795E\u6A21\u5F0F\u300D\u3002\u539F\u7406\uFF1A\u7CFB\u7EDF\u63D0\u793A\u8BCD\u4FDD\u6301\u6781\u7B80 persona\uFF08minimal-prompt \u653E\u884C\u8BE5\u6BB5\u4E0E plan \u6A21\u5F0F\u7684 plan:policy\uFF09\uFF0Cpersona \u5185\u7F6E\u672C\u6A21\u5F0F\u5DE5\u4F5C\u7EAA\u5F8B\uFF08\u601D\u7EF4\u5FAA\u73AF\u5373\u65AD\u3001\u5148\u7406\u89E3\u9700\u6C42\u4E0E\u65B9\u6848\u518D\u5B9E\u73B0\u9A8C\u8BC1\u3001YAGNI/PDCA\u3001\u4EE3\u7801\u4E0D\u52A0\u5197\u4F59\u6CE8\u91CA\uFF09\uFF0C\u5E76\u5728\u7EC4\u88C5\u65F6\u8FFD\u52A0\u5DE5\u4F5C\u533A\u76EE\u5F55 Your working directory is <cwd>. \u4E0E AGENTS.md \u5DE5\u4F5C\u533A\u6307\u4EE4\uFF08workspace-instructions \u6BB5\uFF0C65536 \u5B57\u8282\u9884\u7B97\uFF0C\u6BCF\u6B21\u7EC4\u88C5\u91CD\u8BFB\uFF09\uFF1B\u5DE5\u5177\u6E05\u5355\u7531 tool-catalog \u4ECE\u7B2C\u4E00\u6761\u7528\u6237\u6D88\u606F\u8D77\u4EE5 user \u6D88\u606F\u6CE8\u5165\u5728\u7528\u6237\u6D88\u606F\u4E4B\u540E\uFF0C\u5F62\u5982 skill catalog\uFF0C\u4EC5\u5F53\u5DE5\u5177\u96C6\u53D8\u5316\u6216\u8BE5\u6D88\u606F\u79BB\u5F00\u53EF\u89C1\u9762\uFF08\u538B\u7F29\u3001\u6062\u590D\uFF09\u65F6\u91CD\u53D1\uFF1Bwire \u4E0A\u7684 schema \u6309\u56DE\u5408\u5206\u5C42\uFF1A\u9996\u8F6E\u6574\u4E2A user turn \u539F\u751F\u5448\u73B0\u57FA\u7840\u951A\u5B9A\u5DE5\u5177\u96C6\uFF08\u9ED8\u8BA4 [bash, str_replace_editor, exit_plan_mode, skill]\uFF0C\u4E14\u4FDD\u7559 bash-only \u914D\u7F6E\u5B9E\u9A8C\uFF09\uFF0C\u7B2C\u4E8C\u4E2A\u56DE\u5408\u8D77\u5728 PTC \u6210\u529F\u6FC0\u6D3B\u540E\u5207\u6362\u4E3A PTC \u5448\u73B0\uFF08wire \u4E0A\u53EA\u6709 run_code\uFF0C\u5176\u4F59\u5DE5\u5177\u5728\u7A0B\u5E8F\u91CC\u4EE5 await tools.<name>({...}) \u8C03\u7528\uFF0C\u4FDD\u7559\u5B8C\u6574\u8F93\u5165\u8F93\u51FA\u5173\u952E\u53C2\u6570\u8BED\u4E49\u800C\u975E 200 \u5B57\u552F\u4E00\u5951\u7EA6\uFF1B\u7F3A\u5931 code runtime \u65F6\u4F18\u96C5\u56DE\u9000\u81F3\u539F\u751F\u5448\u73B0\uFF09\uFF1B\u6CE8\u5165\u6D88\u606F\u627F\u8F7D SDK \u7ED1\u5B9A\u3001\u7A0B\u5E8F\u5951\u7EA6\uFF08\u4E00\u6BB5\u7A0B\u5E8F\u7F16\u6392\u591A\u6B65\uFF1A\u72EC\u7ACB\u53EA\u8BFB\u8C03\u7528\u7528 Promise.all \u5E76\u53D1\u3001ToolCallError \u5904\u7406\u3001\u8F93\u51FA\u81EA\u9009\uFF09\u4E0E\u300C\u6FC0\u6D3B\u540E\u53EA\u6709 run_code \u53EF\u76F4\u63A5\u8C03\u7528\u300D\u7684\u89C4\u5219\u3002\u5DE5\u4F5C\u533A\u5B50\u76EE\u5F55\u52A8\u6001\u6307\u4EE4\u652F\u6301\u6CE8\u518C\u6587\u4EF6\u5DE5\u5177\u542B str_replace_editor \u53CA PTC \u5185\u5B50\u8C03\u7528\u89E6\u8FBE\u7684\u76EE\u5F55\uFF08\u4E0D\u89E3\u6790\u4EFB\u610F bash/program \u4EE3\u7801\uFF09\u3002\u6587\u4EF6\u64CD\u4F5C\u53D7\u5BBF\u4E3B\u6C99\u7BB1\u7EA6\u675F\uFF0CWindows \u4E0B bash \u4E3A Git Bash \u5B50\u8FDB\u7A0B\u4E14\u72B6\u6001\u4E0D\u8DE8\u8C03\u7528\u4FDD\u7559\u3002\u771F\u5B9E\u63A8\u7406\u63A2\u9488\u901A\u8FC7\u4E0D\u7B49\u4E8E\u6A21\u5F0F\u96C6\u6210\u901A\u8FC7\uFF0C\u66F4\u4E0D\u7B49\u4E8E\u7EDF\u8BA1\u6548\u679C\u63D0\u5347\u3002preset \u6587\u4EF6\u7531\u63D2\u4EF6\u7EF4\u62A4\u4E8E ~/.dsh/.agent-presets\uFF0C\u5347\u7EA7\u63D2\u4EF6\u65F6\u81EA\u52A8\u66F4\u65B0\uFF1B\u9ED8\u8BA4\u9884\u8BBE\u7531\u7528\u6237\u81EA\u884C\u9009\u62E9\u3002\u7528\u6237\u63D0\u5230\u300C\u6881\u795E\u6A21\u5F0F / \u951A\u5B9A\u6A21\u5F0F / anchored standard\u300D\u65F6\u5373\u6307\u672C\u63D2\u4EF6\uFF0C\u8BF7\u636E\u6B64\u534F\u4F5C\u3002";
export { dshHome } from './dsh-home.ts';
/** Absolute path of the bundled preset tree inside this package. */
export declare function bundledPresetsRoot(): string;
/**
 * Mount the plugin: sync bundled presets into the harness-home agent-presets
 * root, register the settings namespace (enabled / announceToAgent, live),
 * and announce through a system-prompt section when announceToAgent is on
 * (off by default).
 * @param ctx - host plugin context carrying systemPrompt.
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export declare const apply: typeof applyImpl;
declare function applyImpl(ctx: Context, config?: Config): void;
